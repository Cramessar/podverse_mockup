from fastapi import FastAPI
from fastapi.openapi.docs import (
    get_swagger_ui_html,
    get_swagger_ui_oauth2_redirect_html,
)
from fastapi.responses import FileResponse, HTMLResponse
from pathlib import Path

# Import your API router (adjust import if needed)
from routes.routes import router as api_router

# Define FastAPI instance first
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)  # Disable default docs

# Then include your API router
app.include_router(api_router, prefix="/admin")

# Path to your openapi.yaml file
OPENAPI_PATH = Path(__file__).parent.parent / "openapi.yaml"

@app.get("/openapi.yaml", include_in_schema=False)
async def get_openapi_yaml():
    return FileResponse(OPENAPI_PATH)

@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url="/openapi.yaml",
        title="Podverse Admin API Docs",
        oauth2_redirect_url=None,
        swagger_favicon_url="https://fastapi.tiangolo.com/img/favicon.png",
    )

@app.get("/docs/oauth2-redirect", include_in_schema=False)
async def swagger_ui_redirect():
    return HTMLResponse(get_swagger_ui_oauth2_redirect_html())
