from fastapi import APIRouter

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/dashboard")
async def get_admin_dashboard():
    """
    Get summary dashboard data:
    - user count
    - active podcasts
    - site uptime
    """
    return {
        "message": "Welcome Admin",
        "user_count": 1234,
        "active_podcasts": 567,
        "site_uptime_days": 99.5,
    }

@router.get("/users")
async def list_users(limit: int = 20, offset: int = 0, active: bool = None, joined_after: str = None):
    """
    Return a list of recent registered users with basic info.
    Supports optional filtering and pagination.
    """
    # Dummy static response for now
    return {
        "data": [
            {"id": 1, "email": "user1@example.com", "join_date": "2025-05-01", "listen_time": 120},
            {"id": 2, "email": "user2@example.com", "join_date": "2025-05-10", "listen_time": 300},
        ],
        "meta": {
            "total": 2,
            "limit": limit,
            "offset": offset,
        }
    }

@router.get("/users/{user_id}")
async def get_user(user_id: int):
    """
    Get user details by ID.
    """
    return {"id": user_id, "email": f"user{user_id}@example.com", "join_date": "2025-05-01", "listen_time": 1234}

@router.get("/podcasts")
async def list_podcasts(limit: int = 20, offset: int = 0, popular: bool = None, category: str = None):
    """
    List active podcasts with optional filters and pagination.
    """
    return {
        "data": [
            {"id": 101, "title": "Podverse Daily", "publisher": "Podverse Studios", "episode_count": 125, "total_listens": 12345},
            {"id": 102, "title": "Tech Talk", "publisher": "Tech Media", "episode_count": 80, "total_listens": 6789},
        ],
        "meta": {
            "total": 2,
            "limit": limit,
            "offset": offset,
        }
    }

@router.get("/podcasts/{podcast_id}")
async def get_podcast(podcast_id: int):
    """
    Get podcast detail and stats by ID.
    """
    return {
        "id": podcast_id,
        "title": f"Podcast {podcast_id}",
        "publisher": "Sample Publisher",
        "episode_count": 42,
        "total_listens": 5000,
    }

@router.get("/podcasts/{podcast_id}/episodes")
async def list_episodes(podcast_id: int, limit: int = 20, offset: int = 0):
    """
    List episodes for a specific podcast.
    """
    return {
        "data": [
            {"id": 1001, "title": "Episode 1: Welcome", "podcast_id": podcast_id, "listen_count": 1000},
            {"id": 1002, "title": "Episode 2: Deep Dive", "podcast_id": podcast_id, "listen_count": 850},
        ],
        "meta": {
            "total": 2,
            "limit": limit,
            "offset": offset,
        }
    }

@router.get("/episodes/{episode_id}")
async def get_episode(episode_id: int):
    """
    Get episode detail and stats by ID.
    """
    return {
        "id": episode_id,
        "title": f"Episode {episode_id}",
        "podcast_id": 101,
        "listen_count": 1500,
    }

@router.get("/stats/listening-trends")
async def listening_trends(start_date: str = None, end_date: str = None, podcast_id: int = None, episode_id: int = None):
    """
    Return podcast listening trends over time.
    """
    return {
        "dates": ["2025-05-01", "2025-05-02", "2025-05-03"],
        "listens": [100, 120, 95],
    }

@router.get("/site-uptime")
async def site_uptime():
    """
    Return uptime statistics for the platform.
    """
    return {
        "uptime_days": 99.5,
        "last_downtime": "2025-04-30T14:00:00Z",
        "downtime_duration_minutes": 15,
    }
